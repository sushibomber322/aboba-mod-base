package com.pipiskin.moreingotspipiskin;

import com.google.common.eventbus.EventBus;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod("moreingotspipiskin")
public class MoreIngotsPipiskin {

    private static EventBus Registry;

    public MoreIngotsPipiskin() {
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::setup);
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::doClientStuff);
    }

    private void setup(final FMLCommonSetupEvent event) {
        // Some preinit code if needed
    }

    private void doClientStuff(final FMLClientSetupEvent event) {
        // Some client setup code if needed
    }

    private static void registerIngot(String name) {
        Registry.register(Registry.ITEM, new Identifier("moreingotspipiskin", name), new Item(new Item.Settings().group(ItemGroup.MISC)));
    }

    public static void init() {
        registerIngot("blue_ingot");
        registerIngot("cyan_ingot");
        registerIngot("dark_green_ingot");
        registerIngot("green_ingot");
        registerIngot("light_blue_ingot");
        registerIngot("lime_ingot");
        registerIngot("orange_ingot");
        registerIngot("pink_ingot");
        registerIngot("purple_ingot");
        registerIngot("red_ingot");
        registerIngot("yellow_ingot");
    }

    static {
        init();
    }
}